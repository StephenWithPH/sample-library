# What
A dummy project (1 of 2) to demonstrate what seems like incorrect behavior in pipenv.

# How
Were this a real library `$ python setup.py sdist` would package it up. For convience sake, I checked in the gzipped archive.
